var searchData=
[
  ['othello_2ecc',['othello.cc',['../othello_8cc.html',1,'']]]
];
