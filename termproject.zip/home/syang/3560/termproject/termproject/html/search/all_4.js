var searchData=
[
  ['flip_5fflip',['flip_flip',['../classmain__savitch__14_1_1Othello.html#a49ca2e53baf37714c14c59875c270dc4',1,'main_savitch_14::Othello']]]
];
