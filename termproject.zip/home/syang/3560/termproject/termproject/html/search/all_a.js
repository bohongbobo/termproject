var searchData=
[
  ['pass',['pass',['../classmain__savitch__14_1_1Othello.html#aa471c56d1634172f92acdfcbe3faa363',1,'main_savitch_14::Othello']]],
  ['piece',['Piece',['../classmain__savitch__14_1_1Piece.html',1,'main_savitch_14']]],
  ['play',['play',['../classmain__savitch__14_1_1game.html#a96b7f20479c9c43bacc03b384467cba4',1,'main_savitch_14::game']]]
];
