var searchData=
[
  ['left_5fdown_5flegal',['left_down_legal',['../classmain__savitch__14_1_1Othello.html#a161a5b2a574446e9cf16e66fab96234d',1,'main_savitch_14::Othello']]],
  ['left_5flegal',['left_legal',['../classmain__savitch__14_1_1Othello.html#a50e871a1c0ceb803f3ffc4d4b2987062',1,'main_savitch_14::Othello']]],
  ['left_5fup_5flegal',['left_up_legal',['../classmain__savitch__14_1_1Othello.html#a8ec6b317a873a919836c4be0534427b9',1,'main_savitch_14::Othello']]]
];
