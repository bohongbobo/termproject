var searchData=
[
  ['restart',['restart',['../classmain__savitch__14_1_1Othello.html#abf872b8074bfa4c04119317dc3b39af2',1,'main_savitch_14::Othello']]],
  ['right_5fdown_5flegal',['right_down_legal',['../classmain__savitch__14_1_1Othello.html#a639b1780203d650877491fd69e63871a',1,'main_savitch_14::Othello']]],
  ['right_5flegal',['right_legal',['../classmain__savitch__14_1_1Othello.html#ac094aa06f0df5ef57b03e249f892428e',1,'main_savitch_14::Othello']]],
  ['right_5fup_5flegal',['right_up_legal',['../classmain__savitch__14_1_1Othello.html#ab7af6485f5dc762e92f0858c193e088b',1,'main_savitch_14::Othello']]]
];
