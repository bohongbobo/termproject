var searchData=
[
  ['display_5fmessage',['display_message',['../classmain__savitch__14_1_1game.html#ab8b87c3a1b68634861a8c0ed2b9f1992',1,'main_savitch_14::game::display_message()'],['../classmain__savitch__14_1_1Othello.html#a87ef083b9bc3943a0951f70c3ba9160a',1,'main_savitch_14::Othello::display_message()']]],
  ['display_5fstatus',['display_status',['../classmain__savitch__14_1_1Othello.html#a471f0e8f0e63ed32d764682f60110267',1,'main_savitch_14::Othello']]],
  ['down_5flegal',['down_legal',['../classmain__savitch__14_1_1Othello.html#a1a6041ee29e5586ec07bdfef782731d0',1,'main_savitch_14::Othello']]]
];
