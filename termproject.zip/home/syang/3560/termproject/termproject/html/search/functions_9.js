var searchData=
[
  ['up_5flegal',['up_legal',['../classmain__savitch__14_1_1Othello.html#a23310eaa078cddaf0fd86303f2f191f4',1,'main_savitch_14::Othello']]]
];
