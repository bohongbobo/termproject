var searchData=
[
  ['all_5flegal',['all_legal',['../classmain__savitch__14_1_1Othello.html#a015372a23879814a43aed9b4259f9834',1,'main_savitch_14::Othello']]]
];
