var searchData=
[
  ['evaluate',['evaluate',['../classmain__savitch__14_1_1Othello.html#aa5a29557cb041e963e53f077d7932e16',1,'main_savitch_14::Othello']]]
];
